Aplicación de manejo de CRUD en playlist y canciones. 
Desarrollada en Android Studio con Java y SQLlite. 
